package intern__grails

class KampusController {

    def index() {
        def universitas = Universitas.createCriteria().list {
            eq('alamat', 'Jl. Abdul Rahman Basalamah')
            eq('noHp', '0800980903')
        }

        String namaUniversitas = universitas.namaUniversitas
        def facultys = universitas.facultys
        render facultys.namaFakultas

    }

    def contoh() {
        Fakultas fakultas = Fakultas.get(1)
        render fakultas.universitas.namaUniversitas
    }

}
