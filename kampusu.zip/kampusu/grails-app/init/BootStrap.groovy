import intern__grails.Fakultas
import intern__grails.Universitas

class BootStrap {

    def init = { servletContext ->
        Universitas universitas = new Universitas()
        universitas.namaUniversitas = "Universitas Fajar"
        universitas.alamat = "Jl. Abdul Rahman Basalamah"
        universitas.noHp = "0800980903"
        universitas.kota = "Makassar"
        universitas.save(flush: true, failOnError: true)

        Universitas universitas1 = Universitas.findByNamaUniversitas('Universitas Fajar')

        Fakultas fakultas = new Fakultas()
        fakultas.namaFakultas = "Teknik"
        fakultas.email = "teknik@unifa.ac.id"
        fakultas.fax = "03894952"
        fakultas.telp = "93475927"
        fakultas.universitas = universitas1
        fakultas.save(flush: true, failOnError: true)
    }
    def destroy = {
    }
}
