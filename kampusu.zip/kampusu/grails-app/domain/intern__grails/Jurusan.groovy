package intern__grails

class Jurusan {
    static hasMany = [courses : Matakuliah, students : Mahasiswa]
    String title
    String namaJurusan
    String email
    Fakultas fakultas

    static constraints = {
    }
}
