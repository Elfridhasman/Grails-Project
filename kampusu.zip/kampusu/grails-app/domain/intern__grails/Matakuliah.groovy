package intern__grails

class Matakuliah {
    static  belongsTo = [Jurusan, Mahasiswa, Dosen]
    static hasMany = [majors : Jurusan, lectures : Dosen]
    String kodeMatakuliah
    String namaMatakuliah
    String sks


    static constraints = {
    }
}
