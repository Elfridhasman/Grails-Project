package intern__grails

class Universitas {
    static hasMany = [facultys : Fakultas]
    String namaUniversitas
    String alamat
    String noHp
    String kota

    static constraints = {
    }
}
