package intern__grails

class Fakultas {
    static hasMany = [majors : Jurusan]
    String namaFakultas
    String email
    String fax
    String telp
    Universitas universitas

    static constraints = {
    }
}
