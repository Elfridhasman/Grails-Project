package intern__grails

class Dosen {
//    static  hasMany = []
    String namaDosen
    String nip
    String email
    String telp
    Jurusan jurusan

    static constraints = {
    }
}
