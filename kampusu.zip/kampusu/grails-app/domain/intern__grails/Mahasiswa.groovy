package intern__grails

class Mahasiswa {
    static hasMany = [courses : Matakuliah]
    String namaMahasiswa
    String stambuk
    String telp
    String alamat
    Jurusan jurusan

    static constraints = {
    }
}
